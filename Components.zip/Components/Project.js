import React from "react";
const Project=(props)=>{
    return(
        <React.Fragment>
            <h1>Project</h1>
            <h3>Tech Stack is used</h3>
                <ul>
                {
                    props.techstack.map((item,index)=>
                    {
                        return (
                            <li key={index}>{item}</li> )
                            console.log(item)
                        
                    }
                    )
                }
                </ul>
        </React.Fragment>
    )
}
export default Project;