import React from "react";
const Qualification=(props)=>{
    return(
        <React.Fragment>
            <h1>Qualification</h1>
            <table className="Qualification" border="1">
                
                    <tr>
                        <th>college</th>
                        <th>degree</th>
                        <th>CGPA</th>
                    </tr>
                   
                <tbody>
                    {
                        props.Qualification.map((item,index)=>
                        {
                         return(
                             <tr key={index}>
                                 <td> {item.college} </td>
                                 <td> {item.degree} </td>
                                 <td> {item.marks} </td>
                                </tr>
                         )   
                        
                    })
    
}
</tbody>
</table>
</React.Fragment>
    )
}
export default Qualification;