import React from "react";
import './style.css';
function Introduction(props){
    return(
        <React.Fragment>
            <h1>Introduction </h1>
            <div className="Introduction">
                <div className="name">{props.name}</div>
                <div className="address">{props.address}</div>
                <div className="mail">{props.mail}</div>
            </div>
        </React.Fragment>
    )
}
export default Introduction;